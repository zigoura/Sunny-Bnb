package com.example.ptuxiaki.sunnybnb.models;

/**
 * Created by ctzoum on 7/5/17.
 */

public class AccomodationCard {

    private String location;
    private String price;
    private double rating;

    public AccomodationCard(String location, String price, double rating) {
        this.location = location;
        this.price = price;
        this.rating = rating;
    }

    public String getLocation() {
        return location;
    }

    public String getPrice() {
        return price;
    }

    public double getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return "AccomodationCard{" +
                "location='" + location + '\'' +
                ", price='" + price + '\'' +
                ", rating=" + rating +
                '}';
    }
}
